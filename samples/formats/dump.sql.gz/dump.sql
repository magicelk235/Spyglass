create table t(a);
